
package Textile;


public class OrderService
{
   public double calculateDiscount(double total) {
        if (total > 10000)
        {
            return total * 0.2;
        }
        else if (total > 5000) 
        {
            return total * 0.1;
        }
        else
        {
            return 0;
        }
    }

    public void generateBill(Order order) {
        double total = order.calculateTotal();
        double discount = calculateDiscount(total);

        double finalAmount = total - discount;

        System.out.println("Total: " + total);
        System.out.println("Discount: " + discount);
        System.out.println("Final Amount: " + finalAmount);
    } 
}
