
package Textile;
import java.sql.*;

public class OrderDAO 
{
    public int createOrder(int customerId, double totalAmount) throws Exception 
    {
        Connection con = DBConnection.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO orders(customer_id,total_amount) VALUES(?,?)",
            Statement.RETURN_GENERATED_KEYS
        );

        ps.setInt(1, customerId);
        ps.setDouble(2, totalAmount);
        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        if (rs.next()) {
            return rs.getInt(1);
        }
        return 0;
    } 
}
