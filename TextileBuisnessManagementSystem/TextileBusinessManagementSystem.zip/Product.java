
package Textile;


public class Product 
{
    private int productId;
    private String name;
    private String category;
    private double price;
    private int stockQty;

    public Product(int productId, String name, String category, double price, int stockQty) 
    {
        this.productId = productId;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stockQty = stockQty;
        
        
    }

    public int getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public int getStockQty() {
        return stockQty;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStockQty(int stockQty) {
        this.stockQty = stockQty;
    }

    
   
}
