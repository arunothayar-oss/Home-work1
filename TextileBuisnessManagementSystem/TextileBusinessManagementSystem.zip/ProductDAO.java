
package Textile;
import java.sql.*;
import java.util.*;


public class ProductDAO 
{
   
    public void addProduct(Product p) throws Exception 
    {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO products(name,category,price,stock_qty) VALUES(?,?,?,?)");

        ps.setString(1, p.getName());
        ps.setString(2, p.getCategory());
        ps.setDouble(3, p.getPrice());
        ps.setInt(4, p.getStockQty());

        ps.executeUpdate();
        System.out.println("Product Added");
    }

    public List<Product> getAllProducts() throws Exception 
    {
        List<Product> list = new ArrayList<>();
        Connection con = DBConnection.getConnection();

        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM products");

        while (rs.next()) {
            list.add(new Product(
                rs.getInt("product_id"),
                rs.getString("name"),
                rs.getString("category"),
                rs.getDouble("price"),
                rs.getInt("stock_qty")
            ));
        }
        return list;
     
    }
}
