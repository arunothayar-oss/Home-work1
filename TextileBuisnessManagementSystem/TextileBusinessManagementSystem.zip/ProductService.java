
package Textile;

import java.util.*;

public class ProductService 
{
     ProductDAO dao = new ProductDAO();

    // Stock Check
    public void checkStock(Product p) {
        if (p.getStockQty() <= 0) {
            System.out.println("Out of Stock");
        } else {
            System.out.println("Available");
        }
    }

    // Search (case-insensitive)
    public Product searchByName(List<Product> list, String name) {
        for (Product p : list) {
            if (p.getName().equalsIgnoreCase(name)) {
                return p;
            }
        }
        return null;
    }

    // Sort by price
    public void sortByPrice(List<Product> list) {
        list.sort(Comparator.comparing(Product::getPrice));
    }
}
