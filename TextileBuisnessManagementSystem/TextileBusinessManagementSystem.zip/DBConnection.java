
package Textile;

import java.sql.*;
public class DBConnection
{
     public static Connection getConnection() throws Exception {
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(
            "jdbc:postgresql://localhost:5432/HomeworkDatabase",
            "postgres",
            "meenakshi"
        );
    }
}
