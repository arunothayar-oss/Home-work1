
package Textile;

import java.util.*;
public class MainApp 
{
    public static void main(String[] args) throws Exception
    {
       Scanner sc = new Scanner(System.in);

        ProductDAO dao = new ProductDAO();
        ProductService ps = new ProductService();

        int choice;

        do {

            System.out.println("\n===== TEXTILE BUSINESS MANAGEMENT =====");
            System.out.println("1. Add Product");
            System.out.println("2. View Products");
            System.out.println("3. Search Product");
            System.out.println("4. Sort Products By Price");
            System.out.println("5. Exit");

            System.out.println("Enter Your Choice:");
            choice = sc.nextInt();

            switch (choice) {

                // ===== ADD PRODUCT =====
                case 1:

                    sc.nextLine();

                    System.out.println("Enter Product Name:");
                    String name = sc.nextLine();

                    System.out.println("Enter Category:");
                    String category = sc.nextLine();

                    System.out.println("Enter Price:");
                    double price = sc.nextDouble();

                    System.out.println("Enter Stock Quantity:");
                    int stock = sc.nextInt();

                    Product p = new Product(0, name, category, price, stock);

                    dao.addProduct(p);

                    System.out.println("Product Added Successfully");

                    break;

                // ===== VIEW PRODUCTS =====
                case 2:

                    List<Product> list = dao.getAllProducts();

                    System.out.println("\n===== PRODUCT LIST =====");

                    for (Product pr : list) {

                        System.out.println(
                                pr.getProductId() + " "
                                + pr.getName() + " "
                                + pr.getCategory() + " "
                                + pr.getPrice() + " "
                                + pr.getStockQty()
                        );
                    }

                    break;

                // ===== SEARCH PRODUCT =====
                case 3:

                    List<Product> searchList = dao.getAllProducts();

                    sc.nextLine();

                    System.out.println("Enter Product Name To Search:");
                    String searchName = sc.nextLine();

                    Product found = ps.searchByName(searchList, searchName);

                    if (found != null) {

                        System.out.println("\nProduct Found");

                        System.out.println("ID: " + found.getProductId());
                        System.out.println("Name: " + found.getName());
                        System.out.println("Category: " + found.getCategory());
                        System.out.println("Price: " + found.getPrice());
                        System.out.println("Stock: " + found.getStockQty());

                    } else {

                        System.out.println("Product Not Found");
                    }

                    break;

                // ===== SORT PRODUCTS =====
                case 4:

                    List<Product> sortList = dao.getAllProducts();

                    ps.sortByPrice(sortList);

                    System.out.println("\n===== SORTED PRODUCTS =====");

                    for (Product pr : sortList) {

                        System.out.println(
                                pr.getName() + " - " + pr.getPrice()
                        );
                    }

                    break;

                // ===== EXIT =====
                case 5:

                    System.out.println("Thank You");

                    break;

                default:

                    System.out.println("Invalid Choice");
            }

        } while (choice != 5);
 
    }
}

