
package Textile;
import java.util.List;

public class Order 
{
    private int orderId;
    private Customer customer;
    private List<OrderItem> items;
    private double totalAmount;
    public Order(Customer customer, List<OrderItem> items) 
    {
        this.customer = customer;
        this.items = items;
    }

    public double calculateTotal() 
    {
        totalAmount = 0;
        for (OrderItem item : items) 
        {
            totalAmount += item.getTotal();
        }
        return totalAmount;
    }
}
