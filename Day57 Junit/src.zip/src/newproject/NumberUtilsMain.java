
package newproject;


public class NumberUtilsMain
{
   
    public static void main(String[] args) {

        int num = 5;

        int fact = NumberUtils.factorial(num);
        boolean prime = NumberUtils.isPrime(num);

        System.out.println("Number : " + num);
        System.out.println("Factorial : " + fact);
        System.out.println("Prime : " + prime);

        int num2 = 8;

        System.out.println("Number : " + num2);
        System.out.println("Prime : " + NumberUtils.isPrime(num2));
    }
}

/* Create a Java program to perform the following operations and write JUnit test cases to verify the functionality.

Requirements

Create a class named NumberUtils.

Implement the following methods:

factorial(int n)

This method should return the factorial of a given number.

isPrime(int n)

This method should check whether the given number is prime or not.

Return true if the number is prime.

Return false if the number is not prime.

Create a JUnit test class named NumberUtilsTest.

Write separate test methods to test:

Factorial calculation

Prime number check

Not prime number check

Use appropriate JUnit assertions such as:

assertEquals()

assertTrue()

assertFalse()

Example

Input

Number : 5

Output

Factorial : 120
Prime : true

Input

Number : 8

Output

Prime : false*/