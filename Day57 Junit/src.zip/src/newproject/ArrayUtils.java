
package newproject;


public class ArrayUtils
{

    
    public static int findMax(int[] arr)
    {
       int max = arr[0];

        for(int i = 1; i < arr.length; i++)
        {
            if(arr[i] > max)
            {
                max = arr[i];
            }
        }

        return max;
    }

    public static int findMin(int[] arr)
    {
        int min = arr[0];

        for(int i = 1; i < arr.length; i++)
        {
            if(arr[i] < min)
            {
                min = arr[i];
            }
        }

        return min;
    }
} 
        
 /* Create a Java program to find the Maximum and Minimum value in an integer array.
Write a separate JUnit test class to test both functions.

Requirements

Create a class named ArrayUtils.

Implement the following methods:

findMax(int[] arr) → returns the maximum value in the array.

findMin(int[] arr) → returns the minimum value in the array.

Create a JUnit test class named ArrayUtilsTest.

Write separate test methods to verify:

Maximum value calculation

Minimum value calculation

Use assertEquals() for validation.

Example

Input Array

{12, 5, 8, 20, 3}

Expected Output

Maximum Value : 20
Minimum Value : 3  */   
    
