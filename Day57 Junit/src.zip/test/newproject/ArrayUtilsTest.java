
package newproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ArrayUtilsTest
{

    @BeforeClass
    public static void BeforeClassTest()
    {
        System.out.println("***Array Utils Test Start***");
    }

    @Before
    public void BeforeEachTest()
    {
        System.out.println("Unit Test Start");
    }

    @Test
    public void maxTest()
    {
        int[] arr = {12, 5, 8, 20, 3};

        int res = ArrayUtils.findMax(arr);

        Assert.assertEquals(20, res);

        System.out.println("Max Test Complete");
    }

    @Test
    public void minTest()
    {
        int[] arr = {12, 5, 8, 20, 3};

        int res = ArrayUtils.findMin(arr);

        Assert.assertEquals(3, res);

        System.out.println("Min Test Complete");
    }

    @After
    public void AfterEachTest()
    {
        System.out.println("Unit Test End");
    }

    @AfterClass
    public static void AfterClassTest()
    {
        System.out.println("***Array Utils Test End***");
    }
}
    
    
       
        

    


