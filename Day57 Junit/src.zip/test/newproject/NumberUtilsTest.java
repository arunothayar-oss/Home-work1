
package newproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class NumberUtilsTest 
{ 
    


    @BeforeClass
    public static void beforeClassTest() {
        System.out.println("**Number Utils Test Start**");
    }

    @Before
    public void beforeEachTest() {
        System.out.println("Unit Test Start");
    }

    
    @Test
    public void factorialTest() {

        int res = NumberUtils.factorial(5);

        Assert.assertEquals(120, res);

        System.out.println("Factorial Test Complete");
    }

    
    @Test
    public void primeTest() {

        boolean res = NumberUtils.isPrime(5);

        Assert.assertTrue(res);

        System.out.println("Prime Test Complete");
    }

    
    @Test
    public void notPrimeTest() {

        boolean res = NumberUtils.isPrime(8);

        Assert.assertFalse(res);

        System.out.println("Not Prime Test Complete");
    }

    @After
    public void afterEachTest() {
        System.out.println("Unit Test End");
    }

    @AfterClass
    public static void afterClassTest() {
        System.out.println("**Number Utils Test End**");
    }
}

    
    
