
package BookingSteps;

import java.sql.*;
public class DAOClass
{
   Connection con;
    public   DAOClass()throws Exception
    {
       con=DBConnection.getConnection();
    }
    public void addPassenger(PassengerModel pm)throws Exception
    {
        CallableStatement cs= con.prepareCall("CALL add_passenger(?,?,?)");
        cs.setString(1,pm.getName());
        cs.setInt(2,pm.getAge());
        cs.setString(3,pm.getPhone());
        cs.execute();
        System.out.println("Passenger added Successfully");
             
    }
    public void bookTicket(BookingModel bm) throws Exception
    {
        CallableStatement cs=con.prepareCall("CALL book_ticket(?,?,?)");
        cs.setInt(1,bm.getPassengerId());
        cs.setInt(2,bm.getBusId());
        cs.setInt(3,bm.getSeatsBooked());
        cs.execute();
        System.out.println("Tickets Booked Successfully");
    
    }
    public void cancelTicket(int bookingId)throws Exception
    {
        CallableStatement cs=con.prepareCall("CALL cancel_ticket(?)");
        cs.setInt(1, bookingId);
        cs.execute();
        System.out.println("Ticket cancelled Successfully");
    }
    public void viewTicketDetails()throws Exception
    {
        Statement st=con.createStatement();
        ResultSet rs= st.executeQuery("select * from Booking");
        while(rs.next())
        {
            System.out.println("Booking Id:"+rs.getInt(1)+"Passenger Id:"
                    +rs.getInt(2)+"Bus Id:"+rs.getInt(3)+"Seats:"+rs.getInt(4)
            +"Status:"+rs.getString(5));
        
        }
    
    }
    public void availableSeats(int busId)throws Exception
    {
        CallableStatement cs= con.prepareCall("{ ? = call available_seats_fun(?) }");
        cs.registerOutParameter(1,Types.INTEGER);
        cs.setInt(2, busId);
        cs.execute();
        int seats= cs.getInt(1);
        System.out.println("Available seats:"+seats);
    
    }
    public void viewBusDetails()throws Exception
    {
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from Bus");
        while(rs.next())
        {
          BusModel bm=new BusModel(rs.getInt(1),rs.getString(2),
          rs.getString(3),rs.getString(4),rs.getInt(5),rs.getInt(6));
          System.out.println(bm.getBusId()+" " +bm.getBusName()+" "+
          bm.getSource()+" " +bm.getDestination()+ " " +bm.getTotalseats()
          +" " +bm.getAvailableSeats());
        
        }
    
    }
    
}
