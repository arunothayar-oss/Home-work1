
package BookingSteps;

import java.sql.*;
public class DBConnection 
{
    public static Connection getConnection()throws Exception
    {
      Class.forName("org.postgresql.Driver");
      String url="jdbc:postgresql://localhost:5432/HomeworkDatabase";
      String user="postgres";
      String password="meenakshi";
      return DriverManager.getConnection(url,user,password);
     
    
    
    }
}
