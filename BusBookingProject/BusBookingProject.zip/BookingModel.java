
package BookingSteps;


public class BookingModel 
{
    private int bookingId;
    private int passengerId;
    private int busId;
    private int seatsBooked;
    private String bookingStatus;

    public BookingModel(int bookingId, int passengerId, int busId, int seatsBooked, String bookingStatus) {
        this.bookingId = bookingId;
        this.passengerId = passengerId;
        this.busId = busId;
        this.seatsBooked = seatsBooked;
        this.bookingStatus = bookingStatus;
    }

    public int getBookingId() {
        return bookingId;
    }

    public int getPassengerId() {
        return passengerId;
    }

    public int getBusId() {
        return busId;
    }

    public int getSeatsBooked() {
        return seatsBooked;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }
    
}
