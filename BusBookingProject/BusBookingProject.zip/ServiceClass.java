
package BookingSteps;


public class ServiceClass 
{
    DAOClass dao;
    public  ServiceClass()throws Exception
    {
        dao=new DAOClass();
        System.out.println("DAO class get initialized");
    }
    public void addPassenger(String name,int age,String phone)throws Exception
    {
        PassengerModel pm= new PassengerModel(name,age,phone);
        dao.addPassenger(pm);
    }
    public void bookTicket(int pid,int bid,int seats)throws Exception
    {
        BookingModel bm=new BookingModel(0,pid,bid,seats,"Booked");
        dao.bookTicket(bm);
    }
    public void cancelTicket(int bookingId)throws Exception
    {
        dao.cancelTicket(bookingId);
    
    }
    public void ticketDetails()throws Exception
    {
        dao.viewTicketDetails();
    }
    public void availableSeats(int busid)throws Exception
    {
    
    dao.availableSeats(busid);
    }
    public void busDetails()throws Exception
    {
        dao.viewBusDetails();
    }
}
