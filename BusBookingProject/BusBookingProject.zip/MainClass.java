
package BookingSteps;

import java.util.Scanner;
public class MainClass 
{
    public static void main(String[] args)throws Exception
    {
        Scanner sc=new Scanner(System.in);
        ServiceClass sl=new ServiceClass();
        while(true)
        {
            System.out.println("\n ****** BUS BOOKING SYSTEM*****");
            System.out.println("1.Add Passenger");
            System.out.println("2.Book Ticket");
            System.out.println("3.Cancel Ticket");
            System.out.println("4.View Ticket Details");
            System.out.println("5.View Available Seats");
            System.out.println("6.View Bus Details");
            System.out.println("7.Exit");
            System.out.println("Enter the choice :");
            int choice = sc.nextInt();
            switch(choice)
            {
                case 1 :
                {
                    sc.nextLine();
                    System.out.println("Enter the name:");
                    String name =sc.nextLine();
                    System.out.println("Enter the age:");
                    int age=sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the number");
                    String phone=sc.nextLine();
                    sl.addPassenger(name, age, phone);
                    break;
                }
                case 2:
                {
                    System.out.println("Enter the passenger Id:");
                    int pid=sc.nextInt();
                    System.out.println("Enter the bus id:");
                    int bid=sc.nextInt();
                    System.out.println("Enter the no of seats");
                    int seats=sc.nextInt();
                    sl.bookTicket(pid, bid, seats);
                    break;
                }
                case 3:
                {
                    System.out.println("Enter the Booking Id:");
                    int bookingId=sc.nextInt();
                    sl.cancelTicket(bookingId);
                    break;
                }
                case 4 :
                {
                   sl.ticketDetails();
                   break;
                }
                case 5:
                {
                    System.out.println("Enter the Bus Id:");
                    int busId=sc.nextInt();
                    sl.availableSeats(busId);
                    break;
                }
                case 6:
                {
                   sl.busDetails();
                   break;
                }
                case 7:
                {
                    System.out.println("Thank You");
                    System.exit(0);
                    break;
                }
                    
            
            
            }
        
        }
    }
 
}
