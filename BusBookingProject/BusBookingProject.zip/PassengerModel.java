
package BookingSteps;


public class PassengerModel 
{
 private int id;
 private String name;
 private int age;
 private String phone;

    public PassengerModel(String name, int age, String phone)
    {
       
        this.name = name;
        this.age = age;
        this.phone = phone;
    }

   public PassengerModel(int id,String name,int age,String phone)
    {
        this.id = id;
        this.name = name;
        this.age = age;
        this.phone = phone;
    }
    public int getId()
    {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPhone() {
        return phone;
    }
 
    
    
}
