
package BookingSteps;


public class BusModel 
{
    private int busId;
    private String busName;
    private String source;
    private String destination;
    private int totalseats;
    private int availableSeats;

    public BusModel(int busId, String busName, String source, String destination, int totalseats, int availableSeats) {
        this.busId = busId;
        this.busName = busName;
        this.source = source;
        this.destination = destination;
        this.totalseats = totalseats;
        this.availableSeats = availableSeats;
    }

    public int getBusId() {
        return busId;
    }

    public String getBusName() {
        return busName;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public int getTotalseats() {
        return totalseats;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    
    
}

