
package junitadvancedfeatures;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

 class StringTimeoutTest
{

    StringOperations obj = new StringOperations();

    @Test
    @Timeout(2)
    void testReverseTimeout() {

        obj.reverse("performance");

    }
}

