
package junitadvancedfeatures;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
    BankAccountTest.class
        
})

public class BankTestSuite 
{
    
}
