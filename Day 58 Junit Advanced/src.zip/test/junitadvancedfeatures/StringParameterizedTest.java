
package junitadvancedfeatures;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;


public class StringParameterizedTest
{
    StringOperations obj = new StringOperations();

    @ParameterizedTest
    @ValueSource(strings = {"java", "junit", "test"})
    void testUpperCase(String input)
    {

        String expected = input.toUpperCase();
        String actual = obj.toUpperCase(input);

        assertEquals(expected, actual);
    }

}
