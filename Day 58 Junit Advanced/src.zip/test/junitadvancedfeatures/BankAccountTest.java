
package junitadvancedfeatures;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class BankAccountTest
{

    BankAccount acc;

    // Deposit Test
    @ParameterizedTest
    @ValueSource(doubles = {100,200,300})
    void testDeposit(double amount) {
        acc = new BankAccount();
        acc.deposit(amount);
        assertEquals(amount, acc.checkBalance());
    }

    // Withdraw Test
    @Test
    void testWithdraw() {
        acc = new BankAccount();
        acc.deposit(500);
        acc.withdraw(200);
        assertEquals(300, acc.checkBalance());
    }

    // Exception Test
    @Test
    void testWithdrawException() {
        acc = new BankAccount();
        acc.deposit(100);

        assertThrows(IllegalArgumentException.class, () -> {
            acc.withdraw(500);
        });
    }

    // Timeout Test
    @Test
    @Timeout(2)
    void timeoutTest() {
        acc = new BankAccount();
        acc.deposit(1000);
        acc.checkBalance();
    }
}
