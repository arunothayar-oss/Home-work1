
package junitadvancedfeatures;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class StringExceptionTest 
{

    StringOperations obj = new StringOperations();

    @Test
    void testReverseException()
    {

        assertThrows(IllegalArgumentException.class, () -> {

            obj.reverse(null);

        });

    }
}


