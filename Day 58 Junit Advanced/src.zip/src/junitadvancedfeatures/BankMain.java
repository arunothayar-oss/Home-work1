
package junitadvancedfeatures;

import java.util.Scanner;
public class BankMain 
{
    



    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BankAccount acc = new BankAccount();

        int choice;

        do {

            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");

            System.out.println("Enter choice:");
            choice = sc.nextInt();

            switch(choice) {

                case 1:
                    System.out.println("Enter amount:");
                    double d = sc.nextDouble();
                    acc.deposit(d);
                    break;

                case 2:
                    System.out.println("Enter amount:");
                    double w = sc.nextDouble();
                    acc.withdraw(w);
                    break;

                case 3:
                    System.out.println("Balance: " + acc.checkBalance());
                    break;

                case 4:
                    System.out.println("Exit");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while(choice != 4);
    }
}

