
package junitadvancedfeatures;

public class StringOperations 
{


    public int getLength(String str) {
        return str.length();
    }

    public String reverse(String str) {
       if(str == null)
       {
            throw new IllegalArgumentException("String cannot be null");
        }  
        
        
        String rev = "";
        for(int i = str.length() - 1; i >= 0; i--) {
            rev = rev + str.charAt(i);
        }
        return rev;
    }
    

    public String toUpperCase(String str) {
        return str.toUpperCase();
    }
}
   
   
    

