
package junitadvancedfeatures;

import java.util.Scanner;


public class StringMain 
{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        StringOperations obj = new StringOperations();

        System.out.println("Enter a String:");
        String input = sc.nextLine();

        System.out.println("1. Length");
        System.out.println("2. Reverse");
        System.out.println("3. Uppercase");

        System.out.println("Enter choice:");
        int choice = sc.nextInt();

        switch(choice) 
        {

            case 1:
                System.out.println("Length: " + obj.getLength(input));
                break;

            case 2:
                System.out.println("Reverse: " + obj.reverse(input));
                break;

            case 3:
                System.out.println("Uppercase: " + obj.toUpperCase(input));
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
}
