
package junitadvancedfeatures;


public class BankAccount 
{
    private double balance = 0;

    public void deposit(double amount) {
        balance = balance + amount;
    }

    public void withdraw(double amount) {

        if(amount > balance) {
            throw new IllegalArgumentException("Insufficient Balance");
        }

        balance = balance - amount;
    }

    public double checkBalance() {
        return balance;
    }
}

