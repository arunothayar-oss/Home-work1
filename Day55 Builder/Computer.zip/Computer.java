
package builder;


public class Computer 
{
    


    // Final fields → Immutable
    private final String cpu;
    private final String ram;
    private final String hdd;
    private final String graphics;

    // Private constructor
    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.hdd = builder.hdd;
        this.graphics = builder.graphics;
    }

    // Getter methods (No setters → Immutable)
    public String getCpu() {
        return cpu;
    }

    public String getRam() {
        return ram;
    }

    public String getHdd() {
        return hdd;
    }

    public String getGraphics() {
        return graphics;
    }

    // Static Builder Class
    public static class Builder {

        // Required fields
        private String cpu;
        private String ram;

        // Optional fields
        private String hdd;
        private String graphics;

        // Constructor for required fields
        public Builder(String cpu, String ram) {
            this.cpu = cpu;
            this.ram = ram;
        }

        // Method chaining for optional fields
        public Builder setHdd(String hdd) {
            this.hdd = hdd;
            return this;
        }

        public Builder setGraphics(String graphics) {
            this.graphics = graphics;
            return this;
        }

        // Build method
        public Computer build() {
            return new Computer(this);
        }
    }
 
}
