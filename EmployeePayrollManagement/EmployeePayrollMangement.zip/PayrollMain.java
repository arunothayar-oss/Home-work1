
package EmploymentSalary;

import java.util.Scanner;
public class PayrollMain 
{

    
    public static void main(String[] args) 
    {
       Scanner sc=new Scanner(System.in);
       try
       {
        EmployeeDAO dao= new EmployeeDAO();
        PayrollService service=new PayrollService();
        int choice;
        do
        {
            System.out.println("\n Employee payroll system");
            System.out.println("1.Add Employee");
            System.out.println("2.View Employee");
            System.out.println("3.Search Employee");
            System.out.println("4.update Employee");
            System.out.println("5.Delete Employee");
            System.out.println("6.Generate paylist");
            System.out.println("7.Exit");
            System.out.println("Enter your choice: ");
            choice=sc.nextInt();
            switch(choice)
            {
                case 1:
                {
                    System.out.println("Enter the employee Id");
                    int id=sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the Employee Name");
                    String name=sc.nextLine();
                    System.out.println("Enter the Department");
                    String dept=sc.nextLine();
                    System.out.println("Enter the Designation");
                    String designation=sc.nextLine();
                    System.out.println("Enter the Basic salary");
                    double salary=sc.nextDouble();
                    Employee e=new Employee(id,name,dept,designation,salary);
                    if(salary<0)
                    {
                        System.out.println("salary can not be negative");
                        break;
                    
                    }
                     service.calculateSalary(e);
                     dao.addEmployee(e);
                     break;
                }
                case 2:
                {
                    dao.viewEmployee();
                    break;
                }
                case 3:
                {
                    System.out.println("Enter the employee id");
                    int id=sc.nextInt();
                    dao.searchEmployee(id);
                    break;
                }
                case 4:
                {
                     System.out.print("Enter Employee ID : ");
                     int id = sc.nextInt();

                      System.out.print("Enter New Salary : ");
                    double newSalary = sc.nextDouble();

                    if(newSalary < 0)
                    {
                        System.out.println("Salary Cannot Be Negative");
                        break;
                    }

                    Employee emp = new Employee(id, newSalary);

                    service.calculateSalary(emp);

                    dao.updateSalary(emp);

                    break;
                }
                case 5:
                {
                    System.out.print("Enter Employee ID : ");
                    int deleteId = sc.nextInt();
                    dao.deleteEmployee(deleteId);
                    break;

                }
                case 6:
                {
                     System.out.print("Enter Employee ID : ");
                      int payId = sc.nextInt();
                      dao.generatePayslip(payId);
                      break;
                }
                case 7:
                {
                System.out.println("Thank You");
                break;
                }
            }
            
        
        }while(choice!=7);
       }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
    }
    
}
