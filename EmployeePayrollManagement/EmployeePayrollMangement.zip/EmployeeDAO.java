
package EmploymentSalary;
import java.sql.*;

public class EmployeeDAO
{
    Connection con;
    public EmployeeDAO()throws Exception
    {
        con=DBConnection.getConnection();
    
    }
    public void addEmployee(Employee e)throws Exception
    {
        String query="Insert into Employee values(?,?,?,?,?,?,?,?,?)";
       PreparedStatement ps= con.prepareStatement(query);
       ps.setInt(1, e.getEmpId());
       ps.setString(2,e.getEmpName());
       ps.setString(3, e.getDepartment());
       ps.setString(4, e.getDesignation());
       ps.setDouble(5, e.getBasicSalary());
       ps.setDouble(6, e.getHra());
       ps.setDouble(7, e.getDa());
       ps.setDouble(8, e.getPf());
       ps.setDouble(9, e.getNetSalary());
       ps.executeUpdate();
       System.out.println("Employee Added Successfully");
    }
    public void viewEmployee()throws Exception
    {
        Statement stmt=con.createStatement();
        ResultSet rs =stmt.executeQuery("Select * from Employee");
        while(rs.next())
        {
            
         System.out.println(rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3)+" | "
            +rs.getString(4)+" | "+rs.getDouble(5)+" | "+rs.getDouble(9));
       
        }
    
    }
    public void searchEmployee(int id)throws Exception
    {
        String query="select * from Employee where emp_id=?";
        PreparedStatement ps= con.prepareStatement(query);
        ps.setInt(1, id);
        ResultSet rs =ps.executeQuery();
        if(rs.next())
        {
            System.out.println("Employee found");
            System.out.println("ID:"+rs.getInt(1));
            System.out.println("Name:"+rs.getString(2));
            System.out.println("Department:"+rs.getString(3));
            System.out.println("Designation:"+rs.getString(4));
            System.out.println("Basic salary:"+rs.getString(5));
            System.out.println("Net Salary:"+rs.getDouble(9));
 
        }
        else
        {
            System.out.println("Employee not found");
        }
    }
        public void updateSalary(Employee e) throws Exception
    {
        String query = "UPDATE Employee SET basic_salary=?, hra=?, da=?, pf=?, net_salary=? WHERE emp_id=?";

        PreparedStatement ps = con.prepareStatement(query);

        ps.setDouble(1, e.getBasicSalary());
        ps.setDouble(2, e.getHra());
        ps.setDouble(3, e.getDa());
        ps.setDouble(4, e.getPf());
        ps.setDouble(5, e.getNetSalary());
        ps.setInt(6, e.getEmpId());
        int rows = ps.executeUpdate();

        if(rows > 0)
        {
            System.out.println("Salary Updated Successfully");
        }
        else
        {
            System.out.println("Employee Not Found");
        }
    }
        public void deleteEmployee(int id)throws Exception
        {
            String query="Delete * from Employee where emp_id=?";
            PreparedStatement ps=con.prepareStatement(query);
            ps.setInt(1, id);
            int rows=ps.executeUpdate();
            if(rows>0)
            {
                System.out.println("Employee details deleted successfully");
            }
            else
            {
                System.out.println("Employee detail not found");
            
            }
        }
            public void generatePayslip(int id) throws Exception
    {
        String query = "SELECT * FROM Employee WHERE emp_id=?";

        PreparedStatement ps = con.prepareStatement(query);

        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        if(rs.next())
        {
            System.out.println("===== PAYSLIP =====");

            System.out.println("Employee ID : " + rs.getInt(1));
            System.out.println("Employee Name : " + rs.getString(2));
            System.out.println("Department : " + rs.getString(3));
            System.out.println("Designation : " + rs.getString(4));

            System.out.println("Basic Salary : " + rs.getDouble(5));
            System.out.println("HRA : " + rs.getDouble(6));
            System.out.println("DA : " + rs.getDouble(7));
            System.out.println("PF : " + rs.getDouble(8));

            System.out.println("Net Salary : " + rs.getDouble(9));
        }
        else
        {
            System.out.println("Employee Not Found");
        }
    }
        
        }
    

