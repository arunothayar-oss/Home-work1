
package EmploymentSalary;


public class PayrollService 
{
    public void calculateSalary(Employee e)
    {
       double basic=e.getBasicSalary();
       double hra=basic*0.20;
       double da=basic*0.10;
       double pf=basic*0.05;
       double netSalary=basic+hra+da-pf;
       e.setHra(hra);
       e.setDa(da);
       e.setPf(pf);
       e.setNetSalary(netSalary);
       
       
    }
}
