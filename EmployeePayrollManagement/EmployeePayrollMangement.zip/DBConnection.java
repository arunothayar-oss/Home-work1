

package EmploymentSalary;
import java.sql.*;

public class DBConnection 
{
    public static Connection getConnection()throws Exception
    {
        Class.forName("org.postgresql.Driver");
        Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/HomeworkDatabase",
                "postgres","meenakshi" );
              
        return con;
    }
}
