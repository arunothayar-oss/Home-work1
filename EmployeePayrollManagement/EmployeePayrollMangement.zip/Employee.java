
package EmploymentSalary;


public class Employee 
{
    private int empId;
    private String empName;
    private String department;
    private String designation;
    private double basicSalary;
    private double hra;
    private double da;
    private double pf;
    private double netSalary;
        public Employee()
            {
        
            }

    public Employee(int empId, String empName, String department, String designation, double basicSalary) 
    {
        this.empId = empId;
        this.empName = empName;
        this.department = department;
        this.designation = designation;
        this.basicSalary = basicSalary;
    }
    public Employee(int empId, double basicSalary)
{
    this.empId = empId;
    this.basicSalary = basicSalary;
}

    public int getEmpId() 
    {
        return empId;
    }

    public void setEmpId(int empId)
    {
        this.empId = empId;
    }

    public String getEmpName()
    {
        return empName;
    }

    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public String getDepartment()
    {
        return department;
    }

    public void setDepartment(String department) 
    {
        this.department = department;
    }

    public String getDesignation()
    {
        return designation;
    }

    public void setDesignation(String designation)
    {
        this.designation = designation;
    }

    public double getBasicSalary() 
    {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary)
    {
        this.basicSalary = basicSalary;
    }

    public double getHra()
    {
        return hra;
    }

    public void setHra(double hra)
    {
        this.hra = hra;
    }

    public double getDa() {
        return da;
    }

    public void setDa(double da)
    {
        this.da = da;
    }

    public double getPf() 
    {
        return pf;
    }

    public void setPf(double pf) 
    {
        this.pf = pf;
    }

    public double getNetSalary() 
    {
        return netSalary;
    }

    public void setNetSalary(double netSalary)
    {
        this.netSalary = netSalary;
    }
    
    
    
}
