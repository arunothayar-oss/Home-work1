
package InventoryScreen;


import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import java.io.IOException;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

import myproject.Session; 

public class InventoryController implements Initializable 
{
 @FXML
    private TableView<String[]> tableView;

    @FXML
    private TableColumn<String[], String> itemColumn;

    @FXML
    private TableColumn<String[], String> quantityColumn;

    @FXML
    private TableColumn<String[], String> unitColumn;

    @FXML
    private TextField itemField;

    @FXML
    private TextField quantityField;

    @FXML
    private ComboBox<String> unitCombo;

    @FXML
    private Button addBtn;

    @FXML
    private Button updateBtn;

    @FXML
    private Button deleteBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        
        if(!"Admin".equals(Session.role))
        {
            System.out.println("Access Denied!");

            javafx.application.Platform.runLater(() -> {
                try {
                    Parent root = FXMLLoader.load(
                        getClass().getResource("/myproject/login.fxml")
                    );

                    Stage stage = (Stage) tableView.getScene().getWindow();
                    stage.setScene(new Scene(root));
                    stage.show();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            return;
        }

        
        itemColumn.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue()[0]));

        quantityColumn.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue()[1]));

        unitColumn.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue()[2]));

        
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        unitCombo.getItems().addAll("Kg", "Litre", "Pieces");
    }

    
    @FXML
    private void handleAdd(ActionEvent event)
    {
        String item = itemField.getText();
        String qty = quantityField.getText();
        String unit = unitCombo.getValue();

        
        String[] row = { item, qty, unit };

        
        tableView.getItems().add(row);

      
        itemField.clear();
        quantityField.clear();
        unitCombo.setValue(null);
    }

   
    @FXML
    private void handleUpdate(ActionEvent event)
    {
        int index = tableView.getSelectionModel().getSelectedIndex();

        if(index >= 0)
        {
            String item = itemField.getText();
            String qty = quantityField.getText();
            String unit = unitCombo.getValue();

            String[] updatedRow = { item, qty, unit };

            tableView.getItems().set(index, updatedRow);
        }
    }

   
    @FXML
    private void handleDelete(ActionEvent event)
    {
        int index = tableView.getSelectionModel().getSelectedIndex();

        if(index >= 0)
        {
            tableView.getItems().remove(index);
        }
    }
}
    
    

