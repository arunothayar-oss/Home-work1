
package myproject;
import java.sql.*;


public class DAOClass 
{
  public Connection connect() throws ClassNotFoundException, SQLException
    {
        Class.forName("org.postgresql.Driver");

        String url = "jdbc:postgresql://localhost:5432/RestaurantDataBase";
        String user = "postgres";
        String pass = "meenakshi";

        return DriverManager.getConnection(url, user, pass);
    }

   
    public boolean validateUser(String username, String password, String role) 
            throws ClassNotFoundException, SQLException
    {
        Connection con = connect();

        PreparedStatement ps = con.prepareStatement(
            "SELECT * FROM users WHERE username=? AND password=? AND role=?"
        );

        ps.setString(1, username);
        ps.setString(2, password);
        ps.setString(3, role);

        ResultSet rs = ps.executeQuery();

        return rs.next(); 
    }

   
    public int insertUser(String username, String password, String role) 
            throws ClassNotFoundException, SQLException
    {
        Connection con = connect();

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO users(username, password, role) VALUES(?,?,?)"
        );

        ps.setString(1, username);
        ps.setString(2, password);
        ps.setString(3, role);

        return ps.executeUpdate(); 
    }

    
    public void getUsers() throws ClassNotFoundException, SQLException
    {
        Connection con = connect();

        PreparedStatement ps = con.prepareStatement("SELECT * FROM users");
        ResultSet rs = ps.executeQuery();

        System.out.println("ID\tUsername\tRole");

        while(rs.next())
        {
            System.out.println(
                rs.getInt("user_id") + "\t" +
                rs.getString("username") + "\t" +
                rs.getString("role")
            );
        }
    }

    
    public int updatePassword(String username, String newPassword) 
            throws ClassNotFoundException, SQLException
    {
        Connection con = connect();

        PreparedStatement ps = con.prepareStatement(
            "UPDATE users SET password=? WHERE username=?"
        );

        ps.setString(1, newPassword);
        ps.setString(2, username);

        return ps.executeUpdate();
    }

    
    public int deleteUser(String username) 
            throws ClassNotFoundException, SQLException
    {
        Connection con = connect();

        PreparedStatement ps = con.prepareStatement(
            "DELETE FROM users WHERE username=?"
        );

        ps.setString(1, username);

        return ps.executeUpdate();
    }
}

