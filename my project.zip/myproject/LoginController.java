package myproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.scene.control.Hyperlink;
import javafx.util.Duration;
import myproject1.DashBoardController;

public class LoginController implements Initializable 
{

    @FXML
    private TextField user;

    @FXML
    private Label message;

    @FXML
    private PasswordField password;

    @FXML
    private ComboBox<String> combobox;

    @FXML
    private Hyperlink forgotPasswordLink;

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        combobox.getItems().addAll("Admin", "Staff");
    }

    @FXML
    private void handleLogin(ActionEvent event)
    {
        String userName = user.getText();
        String pass = password.getText();
        String role = combobox.getValue();

        // ✅ Validation
        if(role == null)
        {
            message.setText("Please select role");
            return;
        }

        if(userName.isEmpty() || pass.isEmpty())
        {
            message.setText("Enter Username & Password");
            return;
        }

        ServiceClass service = new ServiceClass();
        ModelClass model = new ModelClass(userName, pass, role);

        try
        {
            if(service.login(model))
            {
                Session.role = role;
                Session.username = userName;

                message.setText("Login Successful");

                PauseTransition pause = new PauseTransition(Duration.seconds(2));

                pause.setOnFinished(e -> {
                    try 
                    {
                        FXMLLoader loader;
                        Parent root;

                        if(role.equals("Admin"))
                        {
                            loader = new FXMLLoader(
                                getClass().getResource("/myproject1/DashBoard.fxml")
                            );
                            root = loader.load();

                            DashBoardController controller = loader.getController();
                            controller.setRole(role);
                        }
                        else
                        {
                            loader = new FXMLLoader(
                                getClass().getResource("/OrderentryScreen/orderentry.fxml")
                            );
                            root = loader.load();
                        }

                        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
                        stage.setScene(new Scene(root));
                        stage.show();

                    } 
                    catch (IOException ex) 
                    {
                        ex.printStackTrace();
                    }
                });

                pause.play();
            }
            else
            {
                message.setText("Invalid Details");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            message.setText("Database Error");
        }
    } // ✅ VERY IMPORTANT: method closed properly

    // 🔽 This method must be OUTSIDE handleLogin
    @FXML
    private void handleForgotPassword(ActionEvent event) 
    {
        try 
        {
            Parent root = FXMLLoader.load(
                getClass().getResource("/SignupScreen/Signup.fxml")
            );

            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}