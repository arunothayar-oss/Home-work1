
package myproject;


public class ServiceClass 
{
     private DAOClass dao = new DAOClass();

    public boolean login(ModelClass user)
    {
       

        if(user.getUsername() == null || user.getUsername().isEmpty())
        {
            System.out.println("Username required");
            return false;
        }

        if(user.getPassword() == null || user.getPassword().isEmpty())
        {
            System.out.println("Password required");
            return false;
        }

        if(user.getRole() == null)
        {
            System.out.println("Role not selected");
            return false;
        }

        // ✅ Call DAO
        try
        {
            return dao.validateUser(
                user.getUsername(),
                user.getPassword(),
                user.getRole()
            );
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
}
