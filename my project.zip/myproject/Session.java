

package myproject;



public class Session 
{
   

    public static String role;
    public static String username ;
    
}


