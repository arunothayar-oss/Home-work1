
package BillingScreen;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;


public class BillingController implements Initializable {

    @FXML
    private ComboBox<?> orderIdCombo;
    @FXML
    private Label billingTable;
    @FXML
    private TableColumn<?, ?> itemColumn;
    @FXML
    private TableColumn<?, ?> qtyColumn;
    @FXML
    private TableColumn<?, ?> priceColumn;
    @FXML
    private TableColumn<?, ?> totalColumn;
    @FXML
    private Label totalAmountLabel;
    @FXML
    private ComboBox<?> paymentCombo;
    @FXML
    private Button generateBtn;
    @FXML
    private Button printBtn;

  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    

    @FXML
    private void handleGenerateBill(ActionEvent event) {
    }

    @FXML
    private void handlePrint(ActionEvent event) {
    }
    
}
