package SignupScreen;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

import SignupScreen.ModelClass;
import SignupScreen.ServiceClass;

public class SignupController implements Initializable 
{

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField newPasswordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private Label message;

    @FXML
    private TextField mobilenumber;

    @Override
    public void initialize(URL url, ResourceBundle rb) {}

    @FXML
    private void handleReset(ActionEvent event)
    {
        String username = emailField.getText(); // email = username
        String newPass = newPasswordField.getText();
        String confirm = confirmPasswordField.getText();

        if(username.isEmpty() || newPass.isEmpty() || confirm.isEmpty())
        {
            message.setText("Fill all fields");
            return;
        }

        if(!newPass.equals(confirm))
        {
            message.setText("Passwords do not match");
            return;
        }

        String role = "Staff"; // default role

        ModelClass model = new ModelClass(username, newPass, role);
        ServiceClass service = new ServiceClass();

        if(service.register(model))
        {
            message.setText("Account Created Successfully");

            // 🔁 Go back to login
            try 
            {
                Parent root = FXMLLoader.load(
                    getClass().getResource("/myproject/login.fxml")
                );

                Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));

            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
        else
        {
            message.setText("User already exists / Error");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) 
    {
        try 
        {
            Parent root = FXMLLoader.load(
                getClass().getResource("/myproject/login.fxml")
            );

            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));

        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}