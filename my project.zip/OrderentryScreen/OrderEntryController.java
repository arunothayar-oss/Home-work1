package OrderentryScreen;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

public class OrderEntryController implements Initializable {

    @FXML
    private TextField tableNoField;

    @FXML
    private ComboBox<String> dishCombo;

    @FXML
    private TextField quantityField;

    @FXML
    private Label priceLabel;

    @FXML
    private Label totalLabel;

    @FXML
    private TableView<String[]> orderTable;

    @FXML
    private TableColumn<String[], String> dishColumn;

    @FXML
    private TableColumn<String[], String> qtyColumn;

    @FXML
    private TableColumn<String[], String> totalColumn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

      
        dishCombo.getItems().addAll("Idli", "Dosa", "Poori");

      
        dishColumn.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue()[0]));

        qtyColumn.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue()[1]));

        totalColumn.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue()[2]));

        orderTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

   
    @FXML
    private void handleAddItem(ActionEvent event) {

        String dish = dishCombo.getValue();
        String qtyText = quantityField.getText();

        if(dish == null || qtyText.isEmpty()) {
            System.out.println("Fill all fields");
            return;
        }

        int qty = Integer.parseInt(qtyText);

       
        int price = 0;

        if(dish.equals("Idli")) price = 10;
        else if(dish.equals("Dosa")) price = 30;
        else if(dish.equals("Poori")) price = 25;

        int total = price * qty;

        
        priceLabel.setText(String.valueOf(price));
        totalLabel.setText(String.valueOf(total));

       
        String[] row = { dish, String.valueOf(qty), String.valueOf(total) };
        orderTable.getItems().add(row);

       
        quantityField.clear();
        dishCombo.setValue(null);
    }

   
    @FXML
    private void handlePlaceOrder(ActionEvent event) {

        System.out.println("Order Placed!");
        System.out.println("Total Items: " + orderTable.getItems().size());
    }

  
    @FXML
    private void handleClear(ActionEvent event) {

        orderTable.getItems().clear();
        priceLabel.setText("");
        totalLabel.setText("");
    }

   
    @FXML
    private void goToOrderEntry(ActionEvent event)
    {
        try
        {
            Parent root = FXMLLoader.load(
                getClass().getResource("/myproject/orderentry.fxml")
            );

            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}