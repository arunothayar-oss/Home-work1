
package myproject1;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import myproject.Session;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

public class DashBoardController implements Initializable{

    @FXML
    private Label totalOrdersLabel;
    @FXML
    private Label totalSalesLabel;
    @FXML
    private Button orderButton;
    @FXML
    private Button billingButton;
    @FXML
    private Button inventoryButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Label availableItemsLabel;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
      if(!"Admin".equals(Session.role))
        {
            System.out.println("Access Denied!");

           
            try {
                Parent root = FXMLLoader.load(
                    getClass().getResource("/myproject/login.fxml")
                );
                Stage stage = (Stage) totalOrdersLabel.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
             return;
        }
      totalOrdersLabel.setText("25");
    totalSalesLabel.setText("₹5000");
    availableItemsLabel.setText("120");
    }    
    public void setRole(String role)
    {
        System.out.println("Role received: " + role);
    }

    @FXML
    private void goToOrder(ActionEvent event) 
    {
          System.out.println("Order button clicked");
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/OrderentryScreen/Orderentry.fxml")
            );
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goToBilling(ActionEvent event) 
    {
          System.out.println("Billing button clicked");
       try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/BillingScreen/Billing.fxml")
            );
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) 
        {
            e.printStackTrace();
        } 
    }

    @FXML
    private void goToInventory(ActionEvent event) 
    {
          System.out.println("Inventory button clicked");
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/InventoryScreen/Inventory.fxml")
            );
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) 
        {
            e.printStackTrace();
        }
        
    }

    @FXML
    private void handleLogout(ActionEvent event) 
    {
          System.out.println("Logout button clicked");
        try {
           
            Session.role = null;

            Parent root = FXMLLoader.load(
                getClass().getResource("/myproject/login.fxml")
            );
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    }

